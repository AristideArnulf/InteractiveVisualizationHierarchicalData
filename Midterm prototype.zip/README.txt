<!-- LIBRARIES USED: -->

-flask
-ete3
-bokeh

To install these libraries use: 'pip install <library>'

<!-- HOW TO RUN -->

The app.py can be run from a terminal using python3. Open a terminal and type:'python app.py' in order to start a local host to visit the files. 
The adress of the localhost is: 'localhost:4555'.
From here everything will speak for himself.
